import {Mobile}from './Mobile';



var emp=new Mobile();
emp.printMobileDetail(101,"LG",2500,"BasicPhone");

var emp1=new Mobile();
emp1.printMobileDetail(102,"Sumsung",2500,"SmartPhone");